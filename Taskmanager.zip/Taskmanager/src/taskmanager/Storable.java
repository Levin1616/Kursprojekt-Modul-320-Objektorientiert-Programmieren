package taskmanager;

/**
 * Interface für alle Objekte, die gespeichert und exportiert werden können.
 */
public interface Storable {

    /** Zeile für die Speicherdatei tasks.txt. */
    String toFileString();

    /** Zeile für den CSV-Export. */
    String toCsvString();
}
