package taskmanager;

import java.time.temporal.ChronoUnit;

/**
 * Mögliche Intervalle einer wiederkehrenden Aufgabe.
 */
public enum Interval {

    DAILY("täglich", ChronoUnit.DAYS),
    WEEKLY("wöchentlich", ChronoUnit.WEEKS),
    MONTHLY("monatlich", ChronoUnit.MONTHS);

    private final String displayName;
    private final ChronoUnit unit;

    Interval(String displayName, ChronoUnit unit) {
        this.displayName = displayName;
        this.unit = unit;
    }

    public String getDisplayName() {
        return displayName;
    }

    public ChronoUnit getUnit() {
        return unit;
    }
}
