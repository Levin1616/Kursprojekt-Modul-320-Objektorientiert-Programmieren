package taskmanager;

import java.io.IOException;

/**
 * Einstiegspunkt des Taskmanagers.
 *
 * @author Levin Kuonen
 * @version 1.0
 */
public class Main {

    public static void main(String[] args) throws IOException {
        FileStorage storage = new FileStorage();
        TaskManager manager = new TaskManager(storage.load());
        new ConsoleUI(manager, storage).run();
        System.out.println("Alle Aufgaben gespeichert. Bis bald!");
    }
}
