package taskmanager;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Eine wiederkehrende Aufgabe. Erbt von {@link Task}.
 */
public class RecurringTask extends Task {

    private final Interval interval;
    private LocalDate dueDate;

    /** Neue wiederkehrende Aufgabe, vom Benutzer erfasst. */
    public RecurringTask(String title, Interval interval, LocalDate dueDate) {
        this(title, LocalDateTime.now(), interval, dueDate);
    }

    /** Überladener Konstruktor: Aufgabe aus der Datei wiederherstellen. */
    public RecurringTask(String title, LocalDateTime createdAt, Interval interval, LocalDate dueDate) {
        super(title, false, createdAt, null);
        this.interval = interval;
        this.dueDate = dueDate;
    }

    /** Statt abzuhaken, springt das Fälligkeitsdatum um ein Intervall weiter. */
    @Override
    public void markAsDone() {
        dueDate = dueDate.plus(1, interval.getUnit());
    }

    @Override
    public String toDisplayString() {
        return "[~] " + getTitle() + "  (" + interval.getDisplayName()
                + ", fällig am " + dueDate.format(DATE_FORMAT) + ")";
    }

    @Override
    public String toFileString() {
        return "RECURRING|" + getTitle() + "|" + getCreatedAt() + "|" + interval + "|" + dueDate;
    }

    @Override
    public String toCsvString() {
        return "Wiederkehrend," + csvTitle() + ",offen," + getCreatedAt().format(DATE_FORMAT) + ","
                + interval.getDisplayName() + "," + dueDate.format(DATE_FORMAT);
    }
}
