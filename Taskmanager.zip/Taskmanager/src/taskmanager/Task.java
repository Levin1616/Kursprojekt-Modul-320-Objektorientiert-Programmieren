package taskmanager;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;

/**
 * Eine einmalige Aufgabe. Basisklasse für {@link RecurringTask}.
 */
public class Task implements Storable {

    /** Datumsformat TT.MM.JJJJ. STRICT lehnt ungültige Daten wie 31.02. ab, statt sie umzurechnen. */
    public static final DateTimeFormatter DATE_FORMAT =
            DateTimeFormatter.ofPattern("dd.MM.uuuu").withResolverStyle(ResolverStyle.STRICT);

    private String title;
    private boolean done;
    private final LocalDateTime createdAt;
    private LocalDateTime completedAt;

    /** Neue Aufgabe, vom Benutzer erfasst. */
    public Task(String title) {
        this(title, false, LocalDateTime.now(), null);
    }

    /** Überladener Konstruktor: Aufgabe aus der Datei wiederherstellen. */
    public Task(String title, boolean done, LocalDateTime createdAt, LocalDateTime completedAt) {
        this.title = checkTitle(title);
        this.done = done;
        this.createdAt = createdAt;
        this.completedAt = completedAt;
    }

    /** Hakt die Aufgabe ab und merkt sich den Zeitpunkt. */
    public void markAsDone() {
        if (!done) {
            done = true;
            completedAt = LocalDateTime.now();
        }
    }

    /** Dauer von der Erstellung bis zur Erledigung (nur für erledigte Aufgaben). */
    public Duration getDurationUntilDone() {
        return Duration.between(createdAt, completedAt);
    }

    public String toDisplayString() {
        return (done ? "[x] " : "[ ] ") + title;
    }

    @Override
    public String toFileString() {
        return "TASK|" + title + "|" + done + "|" + createdAt + "|" + completedAt;
    }

    @Override
    public String toCsvString() {
        return "Einmalig," + csvTitle() + "," + (done ? "erledigt" : "offen") + ","
                + createdAt.format(DATE_FORMAT) + ",,";
    }

    /** Titel in Anführungszeichen, damit Kommas im Titel die CSV-Spalten nicht verschieben. */
    protected String csvTitle() {
        return "\"" + title.replace("\"", "\"\"") + "\"";
    }

    /** Prüft den Titel: nicht leer und ohne |, weil | das Trennzeichen in der Datei ist. */
    private static String checkTitle(String title) {
        if (title.isBlank() || title.contains("|")) {
            throw new IllegalArgumentException("Der Titel darf nicht leer sein und kein | enthalten.");
        }
        return title.trim();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = checkTitle(title);
    }

    public boolean isDone() {
        return done;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
}
