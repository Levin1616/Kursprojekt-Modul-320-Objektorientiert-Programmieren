package taskmanager;

import java.io.Console;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Scanner;

/**
 * Textbasierte Oberfläche: zeigt Aufgaben und Menü an und liest Eingaben.
 */
public class ConsoleUI {

    // ANSI-Escape-Codes für Farben und zum Leeren des Bildschirms (wie der Befehl clear)
    private static final String GREEN = "\u001B[32m";
    private static final String BLUE = "\u001B[34m";
    private static final String RED = "\u001B[31m";
    private static final String RESET = "\u001B[0m";
    private static final String CLEAR_SCREEN = "\u001B[H\u001B[2J\u001B[3J";

    private final TaskManager manager;
    private final FileStorage storage;
    /** Konsole mit Zeilenbearbeitung (Pfeiltasten). Ist null, wenn die Eingabe umgeleitet wird. */
    private final Console console = System.console();
    private final Scanner scanner = new Scanner(System.in, StandardCharsets.UTF_8);
    /** Rückmeldung zur letzten Aktion, wird nach dem Leeren des Bildschirms angezeigt. */
    private String message = "";

    public ConsoleUI(TaskManager manager, FileStorage storage) {
        this.manager = manager;
        this.storage = storage;
    }

    /** Hauptschleife: anzeigen, Befehl ausführen, speichern – bis der Benutzer 0 wählt. */
    public void run() throws IOException {
        int choice;
        do {
            printScreen();
            choice = readNumber("Deine Wahl: ", 0, 7);
            try {
                handleChoice(choice);
            } catch (IllegalArgumentException e) {
                message = color(e.getMessage(), RED);
            }
            storage.save(manager.getTasks());
        } while (choice != 0);
    }

    private void handleChoice(int choice) throws IOException {
        switch (choice) {
            case 1:
                manager.addTask(readText("Titel: "));
                message = color("Aufgabe hinzugefügt.", GREEN);
                break;
            case 2:
                addRecurringTask();
                break;
            case 3:
                manager.getTask(readTaskNumber()).setTitle(readText("Neuer Titel: "));
                message = color("Aufgabe geändert.", GREEN);
                break;
            case 4:
                manager.removeTask(readTaskNumber());
                message = color("Aufgabe gelöscht.", GREEN);
                break;
            case 5:
                Task task = manager.getTask(readTaskNumber());
                task.markAsDone();
                message = color("Erledigt: " + task.toDisplayString(), GREEN);
                break;
            case 6:
                message = statistics();
                break;
            case 7:
                message = color("Exportiert nach: " + storage.exportCsv(manager.getTasks()), GREEN);
                break;
            default:
                // 0 = beenden, die Schleife in run() endet
        }
    }

    private void printScreen() {
        System.out.print(CLEAR_SCREEN);
        System.out.println("=== MEINE AUFGABEN ===");
        List<Task> tasks = manager.getTasks();
        for (int i = 0; i < tasks.size(); i++) {
            Task task = tasks.get(i);
            String line = (i + 1) + ". " + task.toDisplayString();
            if (task.isDone()) {
                line = color(line, GREEN);
            } else if (task instanceof RecurringTask) {
                line = color(line, BLUE);
            }
            System.out.println(line);
        }
        System.out.println();
        System.out.println(message);
        message = "";
        System.out.println("------------------------------------------");
        System.out.println("1 - Einmalige Aufgabe hinzufügen");
        System.out.println("2 - Wiederkehrende Aufgabe hinzufügen");
        System.out.println("3 - Aufgabe bearbeiten");
        System.out.println("4 - Aufgabe löschen");
        System.out.println("5 - Aufgabe als erledigt markieren");
        System.out.println("6 - Statistik anzeigen");
        System.out.println("7 - Als CSV exportieren");
        System.out.println("0 - Speichern und beenden");
    }

    private void addRecurringTask() {
        String title = readText("Titel: ");
        int number = readNumber("Intervall (1 = täglich, 2 = wöchentlich, 3 = monatlich): ", 1, 3);
        manager.addTask(title, Interval.values()[number - 1], readDate("Erstes Fälligkeitsdatum (TT.MM.JJJJ): "));
        message = color("Wiederkehrende Aufgabe hinzugefügt.", GREEN);
    }

    private String statistics() {
        Duration average = manager.averageDurationUntilDone();
        String averageText = average == null ? "noch keine Daten"
                : average.toDays() + " Tage, " + average.toHoursPart() + " Std., " + average.toMinutesPart() + " Min.";
        return "Aufgaben total:        " + manager.getTasks().size()
                + "\nDavon erledigt:        " + manager.countDone()
                + "\nØ Dauer bis erledigt:  " + averageText;
    }

    // ----- Eingaben -----

    /** Liest eine Zeile. Über die Console funktionieren die Pfeiltasten, sonst über den Scanner. */
    private String readText(String prompt) {
        if (console != null) {
            return console.readLine(prompt).trim();
        }
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }

    /** Fragt so lange, bis eine Zahl im erlaubten Bereich eingegeben wird. */
    private int readNumber(String prompt, int min, int max) {
        while (true) {
            try {
                int number = Integer.parseInt(readText(prompt));
                if (number >= min && number <= max) {
                    return number;
                }
            } catch (NumberFormatException e) {
                // keine Zahl -> Meldung unten
            }
            System.out.println(color("Bitte eine Zahl von " + min + " bis " + max + " eingeben.", RED));
        }
    }

    private int readTaskNumber() {
        int count = manager.getTasks().size();
        if (count == 0) {
            throw new IllegalArgumentException("Es sind keine Aufgaben vorhanden.");
        }
        return readNumber("Nummer der Aufgabe: ", 1, count);
    }

    private LocalDate readDate(String prompt) {
        while (true) {
            try {
                return LocalDate.parse(readText(prompt), Task.DATE_FORMAT);
            } catch (DateTimeParseException e) {
                System.out.println(color("Ungültiges Datum. Beispiel: 24.10.2026", RED));
            }
        }
    }

    private static String color(String text, String color) {
        return color + text + RESET;
    }
}
