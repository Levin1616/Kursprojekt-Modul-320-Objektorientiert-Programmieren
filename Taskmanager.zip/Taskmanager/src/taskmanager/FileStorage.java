package taskmanager;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Laden, Speichern, Backup und CSV-Export.
 */
public class FileStorage {

    private static final Path TASK_FILE = Paths.get("tasks.txt");
    private static final Path BACKUP_FILE = Paths.get("backup.txt");
    private static final Path CSV_FILE = Paths.get("tasks.csv");

    /** Erstellt zuerst ein Backup und lädt dann alle Aufgaben. Fehlerhafte Zeilen werden übersprungen. */
    public List<Task> load() throws IOException {
        List<Task> tasks = new ArrayList<>();
        if (Files.exists(TASK_FILE)) {
            Files.copy(TASK_FILE, BACKUP_FILE, StandardCopyOption.REPLACE_EXISTING);
            for (String line : Files.readAllLines(TASK_FILE, StandardCharsets.UTF_8)) {
                try {
                    tasks.add(parseLine(line));
                } catch (RuntimeException e) {
                    // fehlerhafte Zeile überspringen, statt abzustürzen
                }
            }
        }
        return tasks;
    }

    public void save(List<Task> tasks) throws IOException {
        List<String> lines = new ArrayList<>();
        for (Task task : tasks) {
            lines.add(task.toFileString());
        }
        Files.write(TASK_FILE, lines, StandardCharsets.UTF_8);
    }

    /** Exportiert alle Aufgaben als CSV und gibt den vollständigen Pfad zurück. */
    public Path exportCsv(List<Task> tasks) throws IOException {
        List<String> lines = new ArrayList<>();
        lines.add("Typ,Titel,Status,Erstellt,Intervall,Fällig");
        for (Task task : tasks) {
            lines.add(task.toCsvString());
        }
        Files.write(CSV_FILE, lines, StandardCharsets.UTF_8);
        return CSV_FILE.toAbsolutePath();
    }

    /** Baut aus einer Zeile wieder das passende Objekt. | muss in Regex mit \\ maskiert werden. */
    private Task parseLine(String line) {
        String[] parts = line.split("\\|");
        if (parts[0].equals("TASK")) {
            LocalDateTime completedAt = parts[4].equals("null") ? null : LocalDateTime.parse(parts[4]);
            return new Task(parts[1], Boolean.parseBoolean(parts[2]), LocalDateTime.parse(parts[3]), completedAt);
        }
        return new RecurringTask(parts[1], LocalDateTime.parse(parts[2]),
                Interval.valueOf(parts[3]), LocalDate.parse(parts[4]));
    }
}
