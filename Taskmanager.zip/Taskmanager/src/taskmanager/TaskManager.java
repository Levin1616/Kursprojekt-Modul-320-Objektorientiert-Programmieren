package taskmanager;

import java.time.Duration;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

/**
 * Verwaltet alle Aufgaben (Aggregation: der TaskManager hat eine Liste von Tasks).
 * Für den Benutzer beginnen die Nummern bei 1, intern bei 0.
 */
public class TaskManager {

    private final List<Task> tasks;

    public TaskManager(List<Task> tasks) {
        this.tasks = tasks;
    }

    /** Fügt eine einmalige Aufgabe hinzu. */
    public void addTask(String title) {
        tasks.add(new Task(title));
    }

    /** Überladen: fügt eine wiederkehrende Aufgabe hinzu. */
    public void addTask(String title, Interval interval, LocalDate firstDueDate) {
        tasks.add(new RecurringTask(title, interval, firstDueDate));
    }

    public Task getTask(int number) {
        return tasks.get(number - 1);
    }

    public void removeTask(int number) {
        tasks.remove(number - 1);
    }

    /** Nur-Lese-Ansicht, damit die Liste nur über den TaskManager geändert wird. */
    public List<Task> getTasks() {
        return Collections.unmodifiableList(tasks);
    }

    public int countDone() {
        int count = 0;
        for (Task task : tasks) {
            if (task.isDone()) {
                count++;
            }
        }
        return count;
    }

    /** Durchschnittliche Dauer bis zur Erledigung oder null, wenn noch nichts erledigt ist. */
    public Duration averageDurationUntilDone() {
        int done = countDone();
        if (done == 0) {
            return null;
        }
        Duration total = Duration.ZERO;
        for (Task task : tasks) {
            if (task.isDone()) {
                total = total.plus(task.getDurationUntilDone());
            }
        }
        return total.dividedBy(done);
    }
}
