#!/bin/sh
# Startskript für macOS: kompiliert und startet den Taskmanager
# -Djdk.console=jdk.internal.le aktiviert die Pfeiltasten bei Java 20/21 (ab Java 22 Standard)
cd "$(dirname "$0")"
javac -encoding UTF-8 -d out src/taskmanager/*.java && java -Djdk.console=jdk.internal.le -cp out taskmanager.Main
