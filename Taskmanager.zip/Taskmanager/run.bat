@echo off
REM Startskript fuer Windows: kompiliert und startet den Taskmanager
chcp 65001 > nul
cd /d "%~dp0"
javac -encoding UTF-8 -d out src\taskmanager\*.java && java -Djdk.console=jdk.internal.le -cp out taskmanager.Main
pause
